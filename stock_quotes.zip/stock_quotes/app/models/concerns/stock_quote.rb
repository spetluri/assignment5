class StockQuote
	include HTTParty

	base_uri 'https://cloud.iexapis.com'
	default_params token: 'pk_c7c12fe704df4fc28679857394f9a591'
	format :json

	def self.for symbols

		symbols_arr = symbols.split(',')

		p symbols_arr

		symbols_arr.map do |symbol|
		 get("/stable/stock/#{symbol}/quote").parsed_response
		end

	end


end