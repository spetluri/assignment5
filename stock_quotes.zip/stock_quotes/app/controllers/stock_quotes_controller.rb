class StockQuotesController < ApplicationController
  def index
    @stocks = params[:symbols] || 'fb,aapl'
    p @stocks
    @quotes = StockQuote.for(@stocks)
    p @quotes
  end
end
