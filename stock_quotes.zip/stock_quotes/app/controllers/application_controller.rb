class ApplicationController < ActionController::Base
end
